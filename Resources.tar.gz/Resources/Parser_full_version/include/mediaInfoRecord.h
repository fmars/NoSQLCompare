#ifndef MEDIAINFORECORD_H
#define MEDIAINFORECORD_H

#include <string>

struct midInfo
{
    int mid;
    float duration;
    char mediaType[40];
};

#endif
