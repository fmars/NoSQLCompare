#ifndef MPUINFORECORD_H
#define MPUINFORECORD_H

#include <string>

struct mpuInfo
{
   std::string fileName;
   std::string mediaType;
};

#endif