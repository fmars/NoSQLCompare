#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <boost/unordered_map.hpp>
#include "mediaInfoRecord.h"
#include "mpuDataRecord.h"


class mediaInfoParser
{
public:
    bool parseMediaFile(const std::string &path, boost::unordered_map <std::string, mpuInfo> &mpuData,boost::unordered_map <std::string, midInfo> &resultMap);
    mediaInfoParser();
private:

}; 
